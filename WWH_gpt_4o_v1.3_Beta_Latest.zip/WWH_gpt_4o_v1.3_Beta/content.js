let tooltip = null;
let linkElement = null;
let hideTimeoutId = null;

document.addEventListener("mouseover", (event) => {
  const hoveredLink = event.target.closest("a");
  if (hoveredLink && hoveredLink.href) {
    // If we hover a new link, or the same link again
    linkElement = hoveredLink;

    // Show or update tooltip after short delay
    clearTimeout(hideTimeoutId);
    setTimeout(() => fetchExplanation(hoveredLink), 300);
  }
});

function fetchExplanation(linkEl) {
  const urlText = linkEl.innerText || linkEl.href;

  chrome.runtime.sendMessage({ action: "fetchExplanation", text: urlText }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("❌ Error sending message to background:", chrome.runtime.lastError);
      return;
    }

    if (response && response.explanation) {
      console.log("✅ Explanation received:", response.explanation);
      showTooltip(linkEl, response.explanation);
    } else {
      console.error("⚠️ No response received from background script.");
    }
  });
}

function showTooltip(linkEl, explanationText) {
  hideTooltip(); // remove any existing tooltip first

  tooltip = document.createElement("div");
  tooltip.className = "hyperlink-tooltip";  // We'll style in CSS

  // ====== Parse AI text into What/Why/How ======
  // Default placeholders
  let what = "No information available.";
  let why = "No information available.";
  let how = "No information available.";

  // Example regex if your AI outputs "What: ... Why: ... How: ..."
  explanationText = explanationText.trim();
  const match = explanationText.match(
    /What:\s*(.*?)(?:Why:|\n|$)\s*Why:\s*(.*?)(?:How:|\n|$)\s*How:\s*(.*)/s
  );
  if (match) {
    what = match[1].trim();
    why = match[2].trim();
    how = match[3].trim();
  }

  // ====== Build single container with 3 stacked sections ======
  tooltip.innerHTML = `
    <div class="aih-segment">
      <div class="aih-heading">What:</div>
      <div class="aih-body">${what}</div>
    </div>
    <div class="aih-segment">
      <div class="aih-heading">Why:</div>
      <div class="aih-body">${why}</div>
    </div>
    <div class="aih-segment">
      <div class="aih-heading">How:</div>
      <div class="aih-body">${how}</div>
    </div>
  `;

  // Add tooltip to the DOM
  document.body.appendChild(tooltip);

  // Position it just under the link
  const rect = linkEl.getBoundingClientRect();
  tooltip.style.left = `${rect.left + window.scrollX}px`;
  tooltip.style.top = `${rect.bottom + window.scrollY + 5}px`;

  // ====== Manage hover so tooltip doesn't vanish while reading ======
  linkEl.addEventListener("mouseleave", handleMouseLeave);
  tooltip.addEventListener("mouseleave", handleMouseLeave);

  linkEl.addEventListener("mouseenter", handleMouseEnter);
  tooltip.addEventListener("mouseenter", handleMouseEnter);
}

// Hide any existing tooltip
function hideTooltip() {
  if (tooltip) {
    tooltip.remove();
    tooltip = null;
  }
}

// Called when mouse leaves link or tooltip, sets short timer
function handleMouseLeave() {
  clearTimeout(hideTimeoutId);
  hideTimeoutId = setTimeout(() => {
    if (!isMouseOverElement(linkElement) && !isMouseOverElement(tooltip)) {
      hideTooltip();
    }
  }, 200);
}

// Cancel the hide timer if mouse re-enters link or tooltip
function handleMouseEnter() {
  clearTimeout(hideTimeoutId);
}

// Utility: checks if the mouse is currently within the bounding rectangle
function isMouseOverElement(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  const x = window.event?.clientX;
  const y = window.event?.clientY;
  if (x == null || y == null) return false;

  return (
    x >= rect.left &&
    x <= rect.right &&
    y >= rect.top &&
    y <= rect.bottom
  );
}
